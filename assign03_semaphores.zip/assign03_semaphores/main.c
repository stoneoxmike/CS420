#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <sys/wait.h>
#include "utils.h"
#include "verify.h"
#include "sem_name.h"



int main(int argc, char** argv)
{
	// NOTE: use these variables for your incoming arguments
    int num_procs = 0;      // DO NOT MODIFY THIS VARIABLE NAME
    int num_threads = 0;    // DO NOT MODIFY THIS VARIABLE NAME
    char* filename = NULL;  // DO NOT MODIFY THIS VARIABLE NAME    



    // TODO: parse arguments



    // TODO: open and write initial '0' to file



	// TODO: open/create named semaphore (set your YCP username as SEM_NAME in sem_name.h)



    // TODO: fork off child processes and wait for them to finish

    
    
    // TODO: clean up and close named semaphore








    /////////////////////////////////////////////////////////////////////////////////////
    // IMPORTANT: The following function calls are intended to test the functionality
    //            of your program.  Do NOT remove these function calls from this file.
    //            BE SURE THAT ALL OF YOU CHILD PROCESSES HAVE TERMINATED BEFORE THIS POINT.
    /////////////////////////////////////////////////////////////////////////////////////
    verify_file_contents(num_procs, num_threads, filename);
    verify_semaphore_cleanup(SEM_NAME);

    return 0;
}

