#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <pthread.h>
#include "utils.h"
#include "verify.h"
#include "sem_name.h"



int main(int argc, char** argv)
{
	// NOTE: use these variables for your incoming arguments
    int num_threads;
    char* filename = NULL;



	// TODO: parse arguments



	// TODO: open/create named semaphore (set your YCP username as SEM_NAME in sem_name.h)



	// TODO: spawn threads to do the work and wait for them to finish



    // TODO: clean up named semaphore








    /////////////////////////////////////////////////////////////////////////////////////
    // IMPORTANT: The following function call is intended to test the functionality
    //            of your program.  Do NOT remove this function call from this file.
    //            BE SURE THAT ALL OF YOU CHILD PROCESSES HAVE TERMINATED BEFORE THIS POINT.
    /////////////////////////////////////////////////////////////////////////////////////
#ifdef FILEWRITER_STANDALONE_MODE
    verify_file_contents(1, num_threads, filename);
#endif

    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////
